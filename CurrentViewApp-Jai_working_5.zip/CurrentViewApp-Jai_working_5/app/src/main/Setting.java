package uk.ucl.group21.currentviewapp.currentviewapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.aditya.adityapc.sqliteloginregistrationexample.R;

public class Setting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
    }
}
