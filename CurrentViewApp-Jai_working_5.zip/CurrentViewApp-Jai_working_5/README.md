# Current View App

This current view app will be deployed to Anna Freud as part of the UCL GC02 Apps Design module.
The team consisting of Jaimin, Tom and Kodarie (Team Leader) will be designing, building and testing the app and aim for a release on the 10th January 2017. 
  
  Fields that still need to be done:
  - Skeleton build
  - Login Screen
  - Dashboard
  - Help Page
  - Help Tutorial
  - Questionnaire function
  - GUI (Front-end)
  - Server connection
  - Idle timer logout
  - Secure login
  
For more information on the individual Tasks, please look at the Projects section of the repository.
Add or change tasks using the kanban method!


last edited 24.11.2016 (T.V)
